import sys, numpy as np, pandas as pd, statsmodels.api as sm, statsmodels.formula.api as smf
from sklearn.metrics import roc_auc_score, brier_score_loss, log_loss
d=pd.read_csv(sys.argv[1]); d=d[d.VisitorType!="Other"].reset_index(drop=True)
d["y"]=d.Revenue.astype(int); d["V"]=(d.VisitorType=="Returning_Visitor").astype(int); d["X"]=d.ProductRelated; d["lx"]=np.log1p(d.X)
print("dups",d.duplicated().sum(), "new/ret", (d.V==0).sum(), (d.V==1).sum())
bands=[-1,0,10,20,40,80,160,10000]
d["band"]=pd.cut(d.X,bands,labels=["0","1-10","11-20","21-40","41-80","81-160",">160"])
print(d.groupby(["V","band"],observed=True).y.agg(["mean","size"]).round(3).unstack(0))
vc=d.TrafficType.value_counts(); small=vc[vc<100].index; d["TT"]=d.TrafficType.where(~d.TrafficType.isin(small),0).astype(str)
print("pooled",d.TrafficType.isin(small).sum())
f={"L0":"y~X","L1":"y~X+V+C(TT)+C(Month)+SpecialDay","L2":"y~lx+V+C(TT)+C(Month)+SpecialDay","L3":"y~lx*V+C(TT)+C(Month)+SpecialDay"}
# folds: keep exact duplicate rows together
prof=pd.factorize(d.drop(columns=["band","TT","lx","X","V","y"]).astype(str).agg("|".join,axis=1))[0]
fold=np.random.default_rng(42).integers(0,5,prof.max()+1)[prof]
for k,fm in f.items():
    p=np.zeros(len(d))
    for i in range(5):
        m=smf.logit(fm,d[fold!=i]).fit(disp=0); p[fold==i]=m.predict(d[fold==i])
    full=smf.logit(fm,d).fit(disp=0,cov_type="HC1")
    extra=""
    if k=="L2": extra=f" OR_V={np.exp(full.params['V']):.3f} CI {np.exp(full.conf_int().loc['V']).round(3).tolist()}"
    if k=="L3": extra=f" eta={full.params['lx:V']:.3f} p={full.pvalues['lx:V']:.3f}"
    print(k,f"AUC={roc_auc_score(d.y,p):.3f} Brier={brier_score_loss(d.y,p):.4f} LL={log_loss(d.y,p):.4f}"+extra)
m2=smf.logit(f["L2"],d).fit(disp=0)
for v in [0,1]:
    out=[]
    for x in [10,20,40,50]:
        t=d.copy(); t["V"]=v; t["lx"]=np.log1p(x); out.append(m2.predict(t).mean()*100)
    print("V",v,[round(o,2) for o in out],"diff10-20",round(out[1]-out[0],2),"diff40-50",round(out[3]-out[2],2))
print("share new >50 pages", ((d.V==0)&(d.X>50)).sum()/(d.V==0).sum())
