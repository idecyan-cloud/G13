"""
DML comparison: original W vs pre-session W
Data: UCI Online Shoppers Purchasing Intention (12,245 sessions, 'Other' removed)
X = ProductRelated, Y = Revenue (0/1)
Partially linear model, 5-fold cross-fitting, Random Forest nuisance models (500 trees, min_samples_leaf=20),
exact duplicate rows kept in the same fold, slope through origin, orthogonal-score SE.
"""
import sys
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
import statsmodels.api as sm

CSV = sys.argv[1]
SEED = 42
K = 5

d = pd.read_csv(CSV)
d = d[d.VisitorType != "Other"].reset_index(drop=True)
d["Revenue"] = d["Revenue"].astype(int)
d["Weekend"] = d["Weekend"].astype(int)
d["NewVisitor"] = (d["VisitorType"] == "New_Visitor").astype(int)
month_order = ["Feb", "Mar", "May", "June", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
d["MonthNum"] = d["Month"].map({m: i for i, m in enumerate(month_order)})

Y = d["Revenue"].to_numpy(float)
X = d["ProductRelated"].to_numpy(float)

W_SETS = {
    "A. Original W (PageValues, Administrative, Informational)":
        ["PageValues", "Administrative", "Informational"],
    "B. Pre-session W (Month, SpecialDay, Weekend, TrafficType, Region, Browser, OS, VisitorType)":
        ["MonthNum", "SpecialDay", "Weekend", "TrafficType", "Region",
         "Browser", "OperatingSystems", "NewVisitor"],
    "C. Report's alternative W (TrafficType, Month, SpecialDay, VisitorType)":
        ["TrafficType", "MonthNum", "SpecialDay", "NewVisitor"],
}


ROW_PROFILE = pd.Series(list(map(tuple, pd.read_csv(CSV).loc[lambda t: t.VisitorType != "Other"].astype(str).to_numpy()))).astype(str)


def grouped_folds(W, k, seed):
    """Keep exact duplicate sessions (identical full feature rows) in the same fold."""
    profile = ROW_PROFILE
    codes, uniq = pd.factorize(profile)
    rng = np.random.default_rng(seed)
    fold_of_group = rng.integers(0, k, size=len(uniq))
    return fold_of_group[codes]


def dml(W, seed=SEED, k=K):
    folds = grouped_folds(W, k, seed)
    g_hat = np.zeros_like(Y)
    m_hat = np.zeros_like(X)
    for f in range(k):
        tr, te = folds != f, folds == f
        clf = RandomForestClassifier(n_estimators=500, min_samples_leaf=20,
                                     random_state=seed, n_jobs=-1)
        clf.fit(W[tr], Y[tr])
        g_hat[te] = clf.predict_proba(W[te])[:, 1]
        reg = RandomForestRegressor(n_estimators=500, min_samples_leaf=20,
                                    random_state=seed, n_jobs=-1)
        reg.fit(W[tr], X[tr])
        m_hat[te] = reg.predict(W[te])
    y_res = Y - g_hat
    x_res = X - m_hat
    theta = np.sum(x_res * y_res) / np.sum(x_res ** 2)
    psi = (y_res - theta * x_res) * x_res
    J = np.mean(x_res ** 2)
    se = np.sqrt(np.mean(psi ** 2) / J ** 2 / len(Y))
    z = theta / se
    p = 2 * stats.norm.sf(abs(z))
    # nuisance model quality
    from sklearn.metrics import roc_auc_score, brier_score_loss
    auc = roc_auc_score(Y, g_hat)
    brier = brier_score_loss(Y, g_hat)
    r2_x = 1 - np.sum(x_res ** 2) / np.sum((X - X.mean()) ** 2)
    return dict(theta=theta, se=se, lo=theta - 1.96 * se, hi=theta + 1.96 * se,
                p=p, auc=auc, brier=brier, r2_x=r2_x)


def ols(Wcols):
    """Multiple regression (linear probability model) with robust SE."""
    Z = sm.add_constant(d[["ProductRelated"] + Wcols].astype(float))
    if "MonthNum" in Wcols:  # month as categories for the linear model
        Z = Z.drop(columns="MonthNum")
        Z = pd.concat([Z, pd.get_dummies(d["Month"], prefix="M", drop_first=True, dtype=float)], axis=1)
    for c in ["TrafficType", "Region", "Browser", "OperatingSystems"]:
        if c in Wcols:
            Z = Z.drop(columns=c)
            Z = pd.concat([Z, pd.get_dummies(d[c], prefix=c[:3], drop_first=True, dtype=float)], axis=1)
    fit = sm.OLS(Y, Z).fit(cov_type="HC1")
    b, s = fit.params["ProductRelated"], fit.bse["ProductRelated"]
    return dict(theta=b, se=s, lo=b - 1.96 * s, hi=b + 1.96 * s, p=fit.pvalues["ProductRelated"])


def fmt(r):
    return (f"theta={r['theta']:.6f}  SE={r['se']:.7f}  95%CI=[{r['lo']:.6f}, {r['hi']:.6f}]  "
            f"p={r['p']:.2e}  per10pages={r['theta']*10*100:.2f}pp")


print(f"n = {len(Y)},  purchase rate = {Y.mean():.4f},  SD(ProductRelated) = {X.std(ddof=1):.2f}")
naive = ols([])
print("\nNo adjustment (simple LPM):\n  " + fmt(naive))

results = {}
for name, cols in W_SETS.items():
    W = d[cols].to_numpy(float)
    r = dml(W)
    results[name] = r
    print(f"\n{name}")
    print("  DML : " + fmt(r))
    print(f"        nuisance: ROC-AUC={r['auc']:.3f}  Brier={r['brier']:.4f}  R2(X|W)={r['r2_x']:.3f}")
    print("  OLS : " + fmt(ols(cols)))

print("\nSeed sensitivity for B:")
WB = d[W_SETS[list(W_SETS)[1]]].to_numpy(float)
for s in [13, 2026]:
    print(f"  seed {s}: theta={dml(WB, seed=s)['theta']:.6f}")
